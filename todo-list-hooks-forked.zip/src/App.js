import React from "react";
import TodoApp from "./TodoApp";

//components

const App = () => (
  <div className="App">
    <TodoApp />
  </div>
);

export default App;
